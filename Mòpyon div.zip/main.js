
    let hasAccount = false;
    let playerName = "Jwè San Kont";
    let isLoggedIn = false;

    // Solo Training Game Variables
    let soloCurrentPlayer = "O";
    let soloGameOver = false;
    let soloGrid;
    const soloSize = 15;

    function showPage(pageId) {
      ['home', 'antre', 'page3'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.classList.add('hidden');
      });
      const target = document.getElementById(pageId);
      if (target) target.classList.remove('hidden');
    }

    function showLoginModal() {
      document.getElementById('loginModal').style.display = 'flex';
    }

    function hideLoginModal() {
      document.getElementById('loginModal').style.display = 'none';
    }

    function showRegisterModal() {
      document.getElementById('registerModal').style.display = 'flex';
    }

    function hideRegisterModal() {
      document.getElementById('registerModal').style.display = 'none';
    }

    function handleLogin(event) {
  event.preventDefault();
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;

  auth.signInWithEmailAndPassword(email, password)
    .then((userCredential) => {
      alert("Koneksyon reyisi!");
      hasAccount = true;
      isLoggedIn = true;
      hideLoginModal();
      showPage('page3');
    })
    .catch((error) => {
      alert("Erè koneksyon: " + error.message);
    });
}

function handleRegister(event) {
  event.preventDefault();
  const name = document.getElementById('registerName').value;
  const email = document.getElementById('registerEmail').value;
  const password = document.getElementById('registerPassword').value;
  const confirmPassword = document.getElementById('confirmPassword').value;

  if (password !== confirmPassword) {
    alert('Modpas yo pa menm!');
    return;
  }

  auth.createUserWithEmailAndPassword(email, password)
    .then((userCredential) => {
      alert("Kont kreye ak siksè!");
      hasAccount = true;
      isLoggedIn = true;
      hideRegisterModal();
      showPage('page3');
      // Tu pourras plus tard enregistrer le nom dans Firestore
    })
    .catch((error) => {
      alert("Erè kreye kont: " + error.message);
    });
}

auth.onAuthStateChanged(function(user) {
  if (user) {
    isLoggedIn = true;
    hasAccount = true;
    playerName = user.email; // ou user.displayName si tu veux gérer le nom plus tard
  } else {
    isLoggedIn = false;
    hasAccount = false;
    playerName = "Jwè San Kont";
  }
});

    function showProfile() {
      const profilePage = document.getElementById('profilePage');
      const playerInfo = document.querySelector('.player-info');
      const tabsContainer = document.querySelector('.tabs-container');
      const moneyContainer = document.querySelector('.money-container');
      
      if (!hasAccount) {
        // Mode sans compte - afficher seulement les boutons de connexion
        profilePage.innerHTML = `
          <header>
            <div></div>
            <div class="logo">Mòpyon</div>
            <button class="nav-button" onclick="hideProfile()">Fèmen</button>
          </header>
          <main>
            <div class="simple-profile">
              <h3>Konekte oswa kreye yon kont pou aksè pwofil ou</h3>
              <button class="button" onclick="showLoginModal(); hideProfile()">Konekte</button>
              <button class="button" onclick="showRegisterModal(); hideProfile()">Kreye kont</button>
            </div>
          </main>
          <footer>
            <p>&copy; 2025 Mòpyon. Tout dwa rezève.</p>
            <p>Kontak | Regleman | Kondisyon itilizasyon</p>
          </footer>
        `;
      }
      
      profilePage.classList.remove('hidden');
    }

    function showTrainingPage() {
      document.getElementById('trainingPage').classList.remove('hidden');
    }

    function hideTrainingPage() {
      document.getElementById('trainingPage').classList.add('hidden');
    }

    function showLearnPage() {
      document.getElementById('learnPage').classList.remove('hidden');
    }

    function hideLearnPage() {
      document.getElementById('learnPage').classList.add('hidden');
    }

    function showAboutPage() {
      document.getElementById('aboutPage').classList.remove('hidden');
    }

    function hideAboutPage() {
      document.getElementById('aboutPage').classList.add('hidden');
    }

    function startSoloTraining() {
      // Cacher complètement toutes les autres pages
      document.getElementById('page3').style.display = 'none';
      document.getElementById('trainingPage').classList.add('hidden');
      document.getElementById('soloGamePage').classList.remove('hidden');
      document.getElementById('soloGamePage').style.display = 'flex';
      initSoloGame();
    }

    function hideSoloGame() {
      document.getElementById('soloGamePage').classList.add('hidden');
      document.getElementById('soloGamePage').style.display = 'none';
      document.getElementById('page3').style.display = 'flex';
      document.getElementById('trainingPage').classList.remove('hidden');
    }

    function showTrainingPage() {
      document.getElementById('trainingPage').classList.remove('hidden');
    }

    function hideTrainingPage() {
      document.getElementById('trainingPage').classList.add('hidden');
    }

    // Solo Training Game Functions
    function initSoloGrid() {
      soloGrid = Array(soloSize).fill().map(() => Array(soloSize).fill(""));
    }

    function createSoloBoard() {
      const board = document.getElementById("soloBoard");
      board.innerHTML = "";
      for (let i = 0; i < soloSize; i++) {
        for (let j = 0; j < soloSize; j++) {
          const cell = document.createElement("div");
          cell.className = "game-cell";
          cell.dataset.x = i;
          cell.dataset.y = j;
          cell.addEventListener("click", makeSoloMove);
          board.appendChild(cell);
        }
      }
    }

    function checkSoloWin(x, y) {
      const dirs = [
        [[0, 1], [0, -1]], // horizontal
        [[1, 0], [-1, 0]], // vertical  
        [[1, 1], [-1, -1]], // diagonal
        [[1, -1], [-1, 1]]  // anti-diagonal
      ];
      
      for (const dir of dirs) {
        let count = 1;
        let line = [[x, y]];
        
        for (const [dx, dy] of dir) {
          let nx = x + dx, ny = y + dy;
          while (nx >= 0 && nx < soloSize && ny >= 0 && ny < soloSize && soloGrid[nx][ny] === soloCurrentPlayer) {
            count++;
            line.push([nx, ny]);
            nx += dx; 
            ny += dy;
          }
        }
        
        if (count >= 5) {
          const sorted = line.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
          return sorted.length ? [sorted[0], sorted[sorted.length - 1]] : null;
        }
      }
      return null;
    }

    function drawSoloStrikeLine(x1, y1, x2, y2) {
      const board = document.getElementById("soloBoard");
      const cell1 = document.querySelector(`#soloBoard [data-x='${x1}'][data-y='${y1}']`).getBoundingClientRect();
      const cell2 = document.querySelector(`#soloBoard [data-x='${x2}'][data-y='${y2}']`).getBoundingClientRect();
      const boardRect = board.getBoundingClientRect();

      const xStart = cell1.left + cell1.width / 2 - boardRect.left;
      const yStart = cell1.top + cell1.height / 2 - boardRect.top;
      const xEnd = cell2.left + cell2.width / 2 - boardRect.left;
      const yEnd = cell2.top + cell2.height / 2 - boardRect.top;

      const length = Math.hypot(xEnd - xStart, yEnd - yStart);
      const angle = Math.atan2(yEnd - yStart, xEnd - xStart) * 180 / Math.PI;

      const line = document.createElement("div");
      line.className = "game-strike-line";
      line.style.width = `${length}px`;
      line.style.left = `${xStart}px`;
      line.style.top = `${yStart}px`;
      line.style.transform = `rotate(${angle}deg)`;

      board.appendChild(line);
    }

    function showSoloWinner(winner, line = null) {
      soloGameOver = true;
      if (line) drawSoloStrikeLine(...line[0], ...line[1]);
      
      document.getElementById("soloWinnerText").textContent = `${winner} genyen!`;
      document.getElementById("soloEndModal").style.display = "flex";
    }

    function makeSoloMove(e) {
      if (soloGameOver) return;
      const cell = e.target;
      const x = +cell.dataset.x;
      const y = +cell.dataset.y;
      if (soloGrid[x][y]) return;
      
      soloGrid[x][y] = soloCurrentPlayer;
      cell.textContent = soloCurrentPlayer;
      cell.style.color = soloCurrentPlayer === "O" ? "red" : "blue";
      
      const line = checkSoloWin(x, y);
      if (line) {
        showSoloWinner(soloCurrentPlayer === "O" ? "Jwè 1" : "Jwè 2", line);
        return;
      }
      
      soloCurrentPlayer = soloCurrentPlayer === "O" ? "X" : "O";
    }

    function initSoloGame() {
      soloGameOver = false;
      soloCurrentPlayer = "O";
      initSoloGrid();
      createSoloBoard();
      
      // S'assurer que les modales sont fermées
      document.getElementById("soloMenuModal").style.display = "none";
      document.getElementById("soloEndModal").style.display = "none";
      
      // Configurer le bouton menu
      const menuBtn = document.getElementById("soloMenuButton");
      if (menuBtn) {
        menuBtn.onclick = () => document.getElementById("soloMenuModal").style.display = "flex";
      }
    }

    function restartSoloGame() {
      document.querySelectorAll("#soloBoard .game-strike-line").forEach(e => e.remove());
      document.getElementById("soloEndModal").style.display = "none";
      document.getElementById("soloMenuModal").style.display = "none";
      initSoloGame();
    }

    function hideProfile() {
      document.getElementById('profilePage').classList.add('hidden');
    }

    function switchTab(tabName) {
      // Remove active class from all tabs
      document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
      });
      
      // Add active class to clicked tab
      event.target.classList.add('active');
      
      // Hide all tab contents
      document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.add('hidden');
      });
      
      // Show selected tab content
      document.getElementById(tabName + 'Content').classList.remove('hidden');
    }

    function showDepositWithdraw() {
      alert('Page depo ak retire ap vini byento!');
    }

    function toggleMenu(show) {
      document.getElementById("menuModal").style.display = show ? "flex" : "none";
    }

    function toggleAlert(show) {
      document.getElementById("alertModal").style.display = show ? "flex" : "none";
    }

function handlePlayClick() {
  if (!hasAccount) {
    toggleAlert(true);
  } else {
    // Vérifier si l'utilisateur est authentifié avec Firebase
    const user = firebase.auth().currentUser;
    
    if (user) {
      // Utilisateur connecté, lancer le jeu
      window.location.href = 'jwe2.html';
    } else {
      // Utilisateur a un compte mais pas connecté à Firebase
      alert("Pwoblèm koneksyon. Tanpri konekte w ankò.");
    }
  }
}
    
  function enregistrerJwè(uid, pseudo) {
    db.collection("players").doc(uid).set({
      pseudo: pseudo,
      elo: 500,
      solde: 0,
      pati: 0,
      viktwa: 0,
      defet: 0
    })
    .then(() => {
      console.log("Jwè anrejistre avèk siksè !");
    })
    .catch((error) => {
      console.error("Erè pandan anrejistreman :", error);
    });
  }
  
  function kreyeKont(email, password, pseudo) {
    auth.createUserWithEmailAndPassword(email, password)
      .then((userCredential) => {
        const user = userCredential.user;

        // Ajouter les infos dans Firestore
        db.collection("players").doc(user.uid).set({
          pseudo: pseudo,
          elo: 500,
          solde: 0,
          pati: 0,
          viktwa: 0,
          defet: 0
        })
        .then(() => {
          alert("Kont kreye avèk siksè !");
        })
        .catch((error) => {
          alert("Erè Firestore: " + error.message);
        });

      })
      .catch((error) => {
        alert("Erè kreasyon kont: " + error.message);
      });
  }
  

  function testeFirestore() {
    db.collection("test").add({
      message: "Firestore mache!",
      timestamp: firebase.firestore.FieldValue.serverTimestamp()
    })
    .then(() => {
      alert("Dokiman an ajoute avèk siksè!");
    })
    .catch((error) => {
      alert("Erè pandan ekriti Firestore: " + error.message);
    });
  }
  
  function testFirestoreConnection() {
  const db = firebase.firestore();
  const docRef = db.collection("testFirestore").doc("doc1");

  // Créer un document
  docRef.set({
    test: "Firestore fonctionne",
    timestamp: new Date().toISOString()
  })
  .then(() => {
    console.log("✅ Document ajouté avec succès !");
    
    // Lire ce document
    return docRef.get();
  })
  .then((doc) => {
    if (doc.exists) {
      console.log("📄 Données lues :", doc.data());
    } else {
      console.warn("❌ Aucun document trouvé !");
    }
  })
  .catch((error) => {
    console.error("❌ Erreur Firestore :", error);
  });
}

// Appeler la fonction au chargement de la page
window.addEventListener('load', testFirestoreConnection);

function startGame() {
  // Vérifier si l'utilisateur est connecté
  const user = firebase.auth().currentUser;
  
  if (user) {
    // Utilisateur connecté, rediriger vers le jeu
    window.location.href = 'jwe2.html';
  } else {
    // Utilisateur non connecté, afficher message
    alert('Ou dwe konekte w pou ka jwe');
    // Ou rediriger vers la page de connexion
  }
}